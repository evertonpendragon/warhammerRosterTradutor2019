**File/Catalogue:** 

**BattleScribe version:** 2.01.

**Platform:** Windows/iOS/Android/Mac/Linux

**Dropbox:** Yes/No

**Description:** Detailed issue description.
